<?php die(); ?>
{
    "branch": "logstore_caliper-0-2016061500",
    "component": "logstore_caliper",
    "snapshot": 0,
    "version": 2016061500
}